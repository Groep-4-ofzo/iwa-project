<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class UserRole extends Model
{
    public $timestamps = false;

    protected $table = 'userroles'; 

    protected $fillable = ['role', 'description'];
}